import time
import torch
import torch.nn.functional as F
import torchvision.utils as utils
from math import log10
from skimage import measure


def to_psnr(enhance, clear):
    imdff = torch.clamp(enhance,0,1)-torch.clamp(clear,0,1)
    rmse = (imdff**2).mean().sqrt()
    psnr_list = 20*torch.log10(1/rmse)
    return psnr_list


def to_ssim_skimage(enhance, clear):
    enhance_list = torch.split(enhance, 1, dim=0)
    clear_list = torch.split(clear, 1, dim=0)

    enhance_list_np = [enhance_list[ind].permute(0, 2, 3, 1).data.cpu().numpy().squeeze() for ind in range(len(enhance_list))]
    clear_list_np = [clear_list[ind].permute(0, 2, 3, 1).data.cpu().numpy().squeeze() for ind in range(len(enhance_list))]
    ssim_list = [measure.compare_ssim(enhance_list_np[ind],  clear_list_np[ind], data_range=1, multichannel=True) for ind in range(len(enhance_list))]

    return ssim_list

#def validation(net, val_data_loader, device, category, save_tag=False):
def validation(net, val_data_loader, device):
    psnr_list = []
    ssim_list = []

    for batch_id, val_data in enumerate(val_data_loader):

        with torch.no_grad():
            haze, gt = val_data
            haze = haze.to(device)
            gt = gt.to(device)
            dehaze = net(haze)


        # --- Calculate the average PSNR --- #
        psnr_list.append(to_psnr(dehaze, gt))

        # --- Calculate the average SSIM --- #
        ssim_list.extend(to_ssim_skimage(dehaze, gt))

        # --- Save image --- #
        #if save_tag:
            #save_image(dehaze, image_name)

    avr_psnr = torch.stack(psnr_list).mean().item()
    avr_ssim = sum(ssim_list) / len(ssim_list)
    return avr_psnr, avr_ssim


# def save_image(dehaze, image_name):
#     dehaze_images = torch.split(dehaze, 1, dim=0)
#     batch_num = len(dehaze_images)
#
#     for ind in range(batch_num):
#         utils.save_image(dehaze_images[ind], './results/{}'.format(image_name[ind][:-3] + 'png'))


def print_log(epoch, num_epochs, one_epoch_time, train_psnr, val_psnr, val_ssim):
    print('({0:.0f}s) Epoch [{1}/{2}], Train_PSNR:{3:.2f}, Val_PSNR:{4:.2f}, Val_SSIM:{5:.4f}'
          .format(one_epoch_time, epoch, num_epochs, train_psnr, val_psnr, val_ssim))

    with open('./data/psnr-ssim.txt', 'a') as f:
                print('Date: {0}s, Time_Cost: {1:.0f}s, Epoch: [{2}/{3}], Train_PSNR: {4:.2f}, Val_PSNR: {5:.2f}, Val_SSIM: {6:.4f}'
               .format(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),one_epoch_time, epoch, num_epochs, train_psnr, val_psnr, val_ssim), file=f)


def adjust_learning_rate(optimizer, epoch,lr_decay=0.5):

    # --- Decay learning rate --- #
    step = 30

    if not epoch % step and epoch > 0:
        for param_group in optimizer.param_groups:
            param_group['lr'] *= lr_decay
            print('Learning rate sets to {}.'.format(param_group['lr']))
    else:
        for param_group in optimizer.param_groups:
            print('Learning rate sets to {}.'.format(param_group['lr']))
