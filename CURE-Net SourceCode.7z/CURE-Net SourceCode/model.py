import torch
import torch.nn as nn
import torch.nn.functional as F
from torchsummary import summary

class ShareSepConv(nn.Module):
    def __init__(self, kernel_size):
        super(ShareSepConv, self).__init__()
        assert kernel_size % 2 == 1, 'kernel size should be odd'
        self.padding = (kernel_size - 1)//2
        weight_tensor = torch.zeros(1, 1, kernel_size, kernel_size)
        weight_tensor[0, 0, (kernel_size-1)//2, (kernel_size-1)//2] = 1
        self.weight = nn.Parameter(weight_tensor)
        self.kernel_size = kernel_size

    def forward(self, x):
        inc = x.size(1)
        expand_weight = self.weight.expand(inc, 1, self.kernel_size, self.kernel_size).contiguous()
        return F.conv2d(x, expand_weight,
                        None, 1, self.padding, 1, inc)

class SmoothDilatedResidualBlock(nn.Module):
    def __init__(self, channel_num, dilation=1, group=1):
        super(SmoothDilatedResidualBlock, self).__init__()
        self.pre_conv1 = ShareSepConv(dilation*2-1)
        self.conv1 = nn.Conv2d(channel_num, channel_num, 3, 1, padding=dilation, dilation=dilation, groups=group, bias=False)
        self.norm1 = nn.InstanceNorm2d(channel_num, affine=True)
        self.pre_conv2 = ShareSepConv(dilation*2-1)
        self.conv2 = nn.Conv2d(channel_num, channel_num, 3, 1, padding=dilation, dilation=dilation, groups=group, bias=False)
        self.norm2 = nn.InstanceNorm2d(channel_num, affine=True)

    def forward(self, x):
        y = F.relu(self.norm1(self.conv1(self.pre_conv1(x))))
        y = self.norm2(self.conv2(self.pre_conv2(y)))
        return F.relu(x+y)

class ResidualBlock(nn.Module):
    def __init__(self, channel_num, dilation=1, group=1):
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv2d(channel_num, channel_num, 3, 1, padding=dilation, dilation=dilation, groups=group, bias=False)
        self.norm1 = nn.InstanceNorm2d(channel_num, affine=True)
        self.conv2 = nn.Conv2d(channel_num, channel_num, 3, 1, padding=dilation, dilation=dilation, groups=group, bias=False)
        self.norm2 = nn.InstanceNorm2d(channel_num, affine=True)

    def forward(self, x):
        y = F.relu(self.norm1(self.conv1(x)))
        y = self.norm2(self.conv2(y))
        return F.relu(x+y)

##########################################################################
def conv(in_channels, out_channels, kernel_size, bias=False, stride = 1):
    return nn.Conv2d(
        in_channels, out_channels, kernel_size,
        padding=(kernel_size//2), bias=bias, stride = stride)


##########################################################################
## Channel Attention Layer
class CALayer(nn.Module):
    def __init__(self, channel, reduction=16, bias=False):
        super(CALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
                nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=bias),
                nn.ReLU(inplace=True),
                nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=bias),
                nn.Sigmoid()
        )

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv_du(y)
        return x * y

class PALayer(nn.Module):    #像素注意力机制
    def __init__(self, channel):
        super(PALayer, self).__init__()
        self.pa = nn.Sequential(
                nn.Conv2d(channel, channel // 16, 1, padding=0, bias=True),
                nn.ReLU(inplace=True),
                nn.Conv2d(channel // 16, 1, 1, padding=0, bias=True),
                nn.Sigmoid()
        )
    def forward(self, x):
        y = self.pa(x)
        return x * y
##########################################################################
## Channel Attention Block (CAB)
class CAB(nn.Module):
    def __init__(self, n_feat, kernel_size, reduction, bias, act):
        super(CAB, self).__init__()
        modules_body = []
        modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
        modules_body.append(act)
        modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))

        self.CA = CALayer(n_feat, reduction, bias=bias)
        self.body = nn.Sequential(*modules_body)

    def forward(self, x):
        res = self.body(x)
        res = self.CA(res)
        res += x
        return res
class PAB(nn.Module):
    def __init__(self, n_feat, kernel_size, bias, act):
        super(PAB, self).__init__()
        modules_body = []
        modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
        modules_body.append(act)
        modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))

        self.PA = PALayer(n_feat)
        self.body = nn.Sequential(*modules_body)

    def forward(self, x):
        res = self.body(x)
        res = self.PA(res)
        res += x
        return res


##########################################################################
class ORB(nn.Module):
    def __init__(self, n_feat, kernel_size, reduction, act, bias, num_cab):
        super(ORB, self).__init__()
        modules_body = []
        modules_body.append(PAB(n_feat, kernel_size, bias=bias, act=act))
        modules_body = [CAB(n_feat, kernel_size, reduction, bias=bias, act=act) for _ in range(num_cab)]
        modules_body.append(PAB(n_feat, kernel_size, bias=bias, act=act))
        modules_body.append(conv(n_feat, n_feat, kernel_size))
        self.body = nn.Sequential(*modules_body)

    def forward(self, x):
        res = self.body(x)
        res += x
        return res

class ORSNet(nn.Module):
    def __init__(self, n_feat, scale_orsnetfeats, kernel_size, reduction, act, bias, num_cab):
        super(ORSNet, self).__init__()
        self.orb1 = ORB(n_feat+scale_orsnetfeats, kernel_size, reduction, act, bias, num_cab)
        self.orb2 = ORB(n_feat+scale_orsnetfeats, kernel_size, reduction, act, bias, num_cab)
        self.orb3 = ORB(n_feat+scale_orsnetfeats, kernel_size, reduction, act, bias, num_cab)
    def forward(self, x):
        x = self.orb1(x)
        x = self.orb2(x)
        x = self.orb3(x)
        return x


##########################################################################
## U-Net

class Encoder(nn.Module):
    def __init__(self,n_feat):
        super(Encoder, self).__init__()
        self.conv1 = nn.Conv2d(64, n_feat, 3, 1, 1, bias=False)
        self.norm1 = nn.InstanceNorm2d(n_feat, affine=True)  #一个channel内做归一化
        self.conv2 = nn.Conv2d(n_feat, n_feat, 3, 1, 1, bias=False)
        self.norm2 = nn.InstanceNorm2d(n_feat, affine=True)
        self.conv3 = nn.Conv2d(n_feat, n_feat, 3, 2, 1, bias=False)
        self.norm3 = nn.InstanceNorm2d(n_feat, affine=True)
        self.gate = nn.Conv2d(64 * 3, 3, 3, 1, 1, bias=True)

        self.res1 = SmoothDilatedResidualBlock(64, dilation=2)
        self.res4 = SmoothDilatedResidualBlock(64, dilation=4)
        self.res7 = ResidualBlock(64, dilation=1)
    def forward(self, x):
        y = F.relu(self.norm1(self.conv1(x)))
        y = F.relu(self.norm2(self.conv2(y)))
        y1 = F.relu(self.norm3(self.conv3(y)))

        y = self.res1(y1)
        y2 = self.res4(y)
        y3 = self.res7(y2)
        gates = self.gate(torch.cat((y1, y2, y3), dim=1))
        gated_y = y1 * gates[:, [0], :, :] + y2 * gates[:, [1], :, :] + y3 * gates[:, [2], :, :]
        return gated_y

class Decoder(nn.Module):
    def __init__(self):
        super(Decoder, self).__init__()

        self.deconv3 = nn.ConvTranspose2d(64, 64, 4, 2, 1)
        self.norm4 = nn.InstanceNorm2d(64, affine=True)
        self.deconv2 = nn.Conv2d(64, 64, 3, 1, 1)
        self.norm5 = nn.InstanceNorm2d(64, affine=True)
        self.deconv1 = nn.Conv2d(64, 64, 1)

    def forward(self, x):
        y = F.relu(self.norm4(self.deconv3(x)))
        y = F.relu(self.norm5(self.deconv2(y)))
        y = self.deconv1(y)
        return y
##########################################################################
class DEB(nn.Module):
    def __init__(self,n_feat):
        super(DEB, self).__init__()

        self.relu = nn.LeakyReLU(0.2, inplace=True)

        self.tanh = nn.Tanh()

        self.refine1 = nn.Conv2d(n_feat, 20, kernel_size=3, stride=1, padding=1)
        self.refine2 = nn.Conv2d(20, 20, kernel_size=3, stride=1, padding=1)

        self.conv1010 = nn.Conv2d(20, 1, kernel_size=1, stride=1, padding=0)
        self.conv1020 = nn.Conv2d(20, 1, kernel_size=1, stride=1, padding=0)
        self.conv1030 = nn.Conv2d(20, 1, kernel_size=1, stride=1, padding=0)

        self.refine3 = nn.Conv2d(3, n_feat, kernel_size=3, stride=1, padding=1)
        self.upsample = F.upsample_nearest

        self.batch1 = nn.InstanceNorm2d(100, affine=True)

    def forward(self, x):
        dehaze = self.relu((self.refine1(x)))
        dehaze = self.relu((self.refine2(dehaze)))
        shape_out = dehaze.data.size()

        shape_out = shape_out[2:4]

        x101 = F.avg_pool2d(dehaze, 32)
        x102 = F.avg_pool2d(dehaze, 16)
        x103 = F.avg_pool2d(dehaze, 8)

        x1010 = self.upsample(self.relu(self.conv1010(x101)), size=shape_out)
        x1020 = self.upsample(self.relu(self.conv1020(x102)), size=shape_out)
        x1030 = self.upsample(self.relu(self.conv1030(x103)), size=shape_out)


        dehaze = torch.cat((x1010, x1020, x1030), 1)
        dehaze = self.tanh(self.refine3(dehaze))

        return dehaze

##########################################################################
class SRB(nn.Module):
    def __init__(self, n_feat, kernel_size,bias):
        super(SRB, self).__init__()
        self.conv1 = conv(n_feat, n_feat, kernel_size, bias=bias)
        self.conv2 = conv(n_feat, 3, kernel_size, bias=bias)
        self.conv3 = conv(64, n_feat, kernel_size, bias=bias)
        self.conv4 =  conv(3, n_feat, kernel_size, bias=bias)


    def forward(self, x_in, x_img):
        x1 = self.conv1(x_in)
        x_img1 = self.conv4(x_img)
        img = x1 + x_img1
        x2 = torch.sigmoid(self.conv3(img))
        x1 = x1*x2
        x1 = x1+x_in
        y  = torch.cat((x1,x_img1),dim=1)
        return y
##########################################################################

##########################################################################
class CURENet(nn.Module):
    def __init__(self, in_c=3, out_c=3, n_feat=64, scale_unetfeats=1, scale_orsnetfeats=16, num_cab=2, kernel_size=3, reduction=4, bias=False):
        super(CURENet, self).__init__()

        act=nn.PReLU()
        self.shallow_feat1 = nn.Sequential(conv(in_c, n_feat, kernel_size, bias=bias), CAB(n_feat,kernel_size, reduction, bias=bias, act=act))
        self.shallow_feat2 = nn.Sequential(conv(in_c, n_feat, kernel_size, bias=bias), CAB(n_feat,kernel_size, reduction, bias=bias, act=act))


        self.stage1_encoder = Encoder(n_feat)
        self.stage1_decoder = Decoder()

        self.stage2_encoder = Encoder(n_feat)
        self.stage2_decoder = Decoder()

        self.Enhance = DEB(n_feat)
        self.srb = SRB(n_feat, kernel_size=1,bias=bias)

        self.stage3_orsnet = ORSNet(n_feat, scale_orsnetfeats,kernel_size, reduction, act, bias, num_cab)


        self.concat12  = conv(n_feat*2, n_feat, kernel_size, bias=bias)
        self.concat23  = conv(n_feat*2, n_feat+scale_orsnetfeats, kernel_size, bias=bias)
        self.tail     = conv(n_feat+scale_orsnetfeats, out_c, kernel_size, bias=bias)

    def forward(self, x3_img):
        # Original-resolution Image for Stage 3
        H = x3_img.size(2)
        W = x3_img.size(3)
        # Two Patches for Stage 2
        x2top_img  = x3_img[:,:,0:int(H/2),:]
        x2bot_img  = x3_img[:,:,int(H/2):H,:]
        # Four Patches for Stage 1
        x1ltop_img = x2top_img[:,:,:,0:int(W/2)]
        x1rtop_img = x2top_img[:,:,:,int(W/2):W]
        x1lbot_img = x2bot_img[:,:,:,0:int(W/2)]
        x1rbot_img = x2bot_img[:,:,:,int(W/2):W]
        ##-------------------------------------------
        ##-------------- Stage 1---------------------
        ##-------------------------------------------
        ## Compute Shallow Features
        x1ltop = self.shallow_feat1(x1ltop_img)
        x1rtop = self.shallow_feat1(x1rtop_img)
        x1lbot = self.shallow_feat1(x1lbot_img)
        x1rbot = self.shallow_feat1(x1rbot_img)  #[2,3,128,128]

        ## Process features of all 4 patches with Encoder of Stage 1
        feat1_ltop = self.stage1_encoder(x1ltop)
        feat1_rtop = self.stage1_encoder(x1rtop)
        feat1_lbot = self.stage1_encoder(x1lbot)
        feat1_rbot = self.stage1_encoder(x1rbot)  #[2,64,64,64]

        ## Concat deep features
        feat1_top = torch.cat((feat1_ltop,feat1_rtop),3)
        feat1_bot = torch.cat((feat1_lbot,feat1_rbot),3) #[2,64,64,128]

        ## Pass features through Decoder of Stage 1
        res1_top = self.stage1_decoder(feat1_top)
        res1_bot = self.stage1_decoder(feat1_bot)  #[2,64,128,256]
        res1_top = self.Enhance(res1_top)
        res1_bot = self.Enhance(res1_bot)

        #-------------------------------------------
        #-------------- Stage 2---------------------
        #-------------------------------------------
        # Compute Shallow Features
        x2top  = self.shallow_feat2(x2top_img)
        x2bot  = self.shallow_feat2(x2bot_img) #[2,64,128,256]

        # Concatenate SRB features of Stage 1 with shallow features of Stage 2
        x2top_cat = self.concat12(torch.cat([x2top,res1_top], 1))
        x2bot_cat = self.concat12(torch.cat([x2bot,res1_bot], 1))#[2,64,128,256]

        ## Process features of both patches with Encoder of Stage 2
        feat2_top = self.stage2_encoder(x2top_cat)
        feat2_bot = self.stage2_encoder(x2bot_cat)#[2,64,64,128]

        ## Concat deep features
        feat2 = torch.cat((feat2_top,feat2_bot),2)#[2,64,128,128]

        # Pass features through Decoder of Stage 2
        res2 = self.stage2_decoder(feat2)#[2,64,256,256]

  

        ##-------------- Stage 3---------------------
        x3_srb = self.srb(res2, x3_img)
        x3_srb =  self.concat23(x3_srb) 
        x3_cat = self.stage3_orsnet(x3_srb) #[2,80,256,256]

        stage3_img = self.tail(x3_cat)

        return stage3_img+x3_img
NET=CURENet()
summary(NET, input_size=[(3, 256, 256)], batch_size=-1, device="cpu")