from glob import glob
from Dataset import Mydataset
from valdata import Valdataset
import time
import torch
import argparse
from torchvision.transforms import Compose, ToTensor, Normalize
from torchvision import transforms
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader
from model import CURENet
from utils import to_psnr, print_log, validation, adjust_learning_rate
from torchvision.models import vgg16
from perceptual import LossNetwork
from pytorch_ssim import msssim,ssim
plt.switch_backend('agg')
import warnings
warnings.filterwarnings("ignore")
# --- Parse hyper-parameters  --- #
parser = argparse.ArgumentParser(description='Hyper-parameters for GridDehazeNet')
parser.add_argument('-learning_rate', help='Set the learning rate', default=0.001, type=float)
parser.add_argument('-train_batch_size', help='Set the training batch size', default=5, type=int)
parser.add_argument('-network_height', help='Set the network height (row)', default=0, type=int)
parser.add_argument('-network_width', help='Set the network width (column)', default=7, type=int)
parser.add_argument('-num_dense_layer', help='Set the number of dense layer in RDB', default=4, type=int)
parser.add_argument('-growth_rate', help='Set the growth rate in RDB', default=16, type=int)
parser.add_argument('-lambda_loss', help='Set the lambda in loss function', default=0.04, type=float)
parser.add_argument('-val_batch_size', help='Set the validation/test batch size', default=1, type=int)
parser.add_argument('-num_epochs', help='num_epochs', default=200, type=int)
args = parser.parse_args()

learning_rate = args.learning_rate
train_batch_size = args.train_batch_size
network_height = args.network_height
network_width = args.network_width
num_dense_layer = args.num_dense_layer
growth_rate = args.growth_rate
lambda_loss = args.lambda_loss
val_batch_size = args.val_batch_size
num_epochs = args.num_epochs

input_image_list = glob(r'./data/raw-890/*')
clear_image_list = glob(r'./data/reference-890/*')
val_input_list = glob(r'./data/val_raw/*')
val_clear_list = glob(r'./data/val_reference/*')

print("train：",len(input_image_list))
print("clear：",len(clear_image_list))
print("val_train：",len(val_input_list))
print("val_clear：",len(val_clear_list))

transform= transforms.Compose([
transforms.Resize((256,256)),
transforms.RandomRotation(0.1),
transforms.ToTensor()
])

transforms= transforms.Compose([
transforms.Resize((256, 256)),
	transforms.ToTensor()
])

device_ids = [0,1,2]
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
net = CURENet()
net = net.to(device)
net = nn.DataParallel(net, device_ids=device_ids)

optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate)

# --- Define the perceptual loss network --- #
vgg_model = vgg16(pretrained=True).features[:16]
vgg_model = vgg_model.to(device)
for param in vgg_model.parameters():
    param.requires_grad = False
loss_network = LossNetwork(vgg_model)
loss_network.eval()
loss_s = ssim

try:
    net.load_state_dict(torch.load("snapshots/" + "Epoch00000" + '.pth'))
    print('--- weight loaded ---')
except:
    print('--- no weight loaded ---')

pytorch_total_params = sum(p.numel() for p in net.parameters() if p.requires_grad)
print("Total_params: {}".format(pytorch_total_params))

train_ds = Mydataset(input_image_list,clear_image_list,transform)
train_dl = torch.utils.data.DataLoader(train_ds,batch_size=train_batch_size,shuffle=True, num_workers=12)
val_ds = Valdataset(val_input_list,val_clear_list,transforms)
val_dl = torch.utils.data.DataLoader(val_ds, batch_size=val_batch_size, shuffle=False, num_workers=12)

# --- Previous PSNR and SSIM in testing --- #
old_val_psnr, old_val_ssim = validation(net, val_dl, device)
print('old_psnr: {0:.2f}, old_ssim: {1:.4f}'.format(old_val_psnr, old_val_ssim))

for epoch in range(num_epochs):
    psnr_list = []
    start_time = time.time()
    adjust_learning_rate(optimizer, epoch)
    for iteration, train_data in enumerate(train_dl):

        input, clear = train_data
        input = input.to(device)
        clear = clear.to(device)
        optimizer.zero_grad()
        net.train()
        enhance= net(input)
        smooth_loss = F.smooth_l1_loss(enhance, clear)   #损失函数1
        perceptual_loss = loss_network(enhance, clear)   #损失函数2
        loss = smooth_loss + lambda_loss*perceptual_loss

        loss.backward()
        optimizer.step()

        # --- To calculate average PSNR --- #
        psnr_list.append(to_psnr(enhance, clear))

        if  ((iteration+1) % 10)==0:
            print('Epoch: {0}, Iteration: {1}'.format(epoch, iteration+1))

    # --- Calculate the average training PSNR in one epoch --- #
    train_psnr = torch.stack(psnr_list).mean().item()

    # --- Save the network parameters --- #
    torch.save(net.state_dict(), "snapshots/" + "Epoch" + str(epoch) + '.pth')

    # --- Use the evaluation model in testing --- #
    net.eval()

    val_psnr, val_ssim = validation(net, val_dl, device)
    one_epoch_time = time.time() - start_time
    print_log(epoch+1, num_epochs, one_epoch_time, train_psnr, val_psnr, val_ssim)

    # --- update the network weight --- #
    if val_psnr >= old_val_psnr:
        #torch.save(net.state_dict(), 'haze_best{}'.format(epoch))
        torch.save(net.state_dict(), "goodsnapshots/" + "Epoch" + str(epoch)+ str(network_height)+str(network_width) + '.pth')
        old_val_psnr = val_psnr
