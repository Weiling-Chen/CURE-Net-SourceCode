import torch.utils.data as data
from PIL import Image
from torchvision.transforms import Compose, ToTensor, Normalize
from torchvision import transforms
from torch.utils import data

class Mydataset(data.Dataset):
  def __init__(self,input_img_paths,clear_image_paths,transform):
    self.input_img_paths = input_img_paths
    self.clear_image_paths = clear_image_paths
    self.input_list = self.input_img_paths
    self.transform = transform

  def __getitem__(self, index):
     input_image_path = self.input_img_paths[index]
     clear_image_path = self.clear_image_paths[index]
     input_image = Image.open(input_image_path).convert('RGB')
     clear_image = Image.open(clear_image_path)

     input_image = self.transform(input_image)
     clear_image = self.transform(clear_image)

     return input_image,clear_image

  def __len__(self):
     return len(self.input_list)
