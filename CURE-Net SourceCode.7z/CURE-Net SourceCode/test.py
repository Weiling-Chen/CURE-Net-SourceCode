import torchvision
import torch.optim
from torch.utils.data import DataLoader
import glob
import time
import numpy as np
import torch
from PIL import Image
import torch.nn as nn
from model import CURENet
from utils import to_psnr, print_log, validation, adjust_learning_rate

def test(image_path):

    device_ids = [0,1,2]
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    image = Image.open(image_path).convert('RGB')
    image = (np.asarray(image)/255.0)
    image = torch.from_numpy(image).float()
    image = image.permute(2,0,1)
    image = image.to(device).unsqueeze(0)

    net = CURENet().to(device)
	#net = Net().to(device)
    net = nn.DataParallel(net, device_ids=device_ids)

    PATH='snapshots/Epoch10.pth'
    net.load_state_dict(torch.load(PATH))
    enhanced_image = net(image)
    net.eval()
    start = time.time()
    print(start)
    print( time.time())
    end_time = (time.time() - start)
    print('validation time is {0:.4f}'.format(end_time))

    image_path = image_path.replace('test_data','result')
    result_path = image_path
    torchvision.utils.save_image(enhanced_image, result_path)

if __name__ == '__main__':
   with torch.no_grad():
     test_image_path = glob.glob('data/test_data/*')
     for image in test_image_path:
          print(image)
          test(image)

